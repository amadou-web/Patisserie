# Casa Délice — plan de développement commercial initial

## Positionnement
Restaurant fast-food à Niaga / Lac Rose, avec une offre variée : burgers, sandwichs, pizzas, mini-tacos, chawarma, nems, fataya viande, riz au poulet et riz au poisson.

Promesse de marque proposée : « Le goût qui vous régale ! »
Ton : gourmand, chaleureux, simple et professionnel.

## Priorités des 30 premiers jours
1. Confirmer prix, horaires, adresse exacte, zones et frais de livraison.
2. Photographier les plats réels dans de bonnes conditions lumineuses.
3. Finaliser le menu en affichant clairement les prix.
4. Tester les commandes WhatsApp avec les deux numéros de l'enseigne.
5. Créer ou mettre à jour les profils sociaux et la fiche établissement.
6. Tenir un registre quotidien des commandes, ventes, coûts et retours clients.

## Menu et rentabilité
Pour chaque produit, mesurer :
- prix de vente ;
- coût ingrédients ;
- emballage ;
- commission éventuelle de livraison ;
- temps de préparation ;
- marge contributive.

Ne lancer les menus combinés qu'après calcul des coûts. Une promotion qui augmente les ventes mais détruit la marge n'est pas une bonne promotion.

## Commandes et livraison
- Confirmer chaque commande manuellement avant préparation.
- Clarifier retrait ou livraison, adresse, frais et délai estimé.
- Utiliser un seul message de confirmation standard.
- Suivre les commandes manquées, retards, erreurs et réclamations.
- Ne pas promettre une livraison rapide tant que la capacité réelle n'est pas mesurée.

## Fidélisation
- Carte de fidélité simple, avec règles faciles à comprendre.
- Offre de bienvenue ponctuelle, après calcul de marge.
- Demander un avis après une commande réussie, sans fabriquer de faux avis.
- Publier les plats du jour, horaires et offres réelles.

## Indicateurs hebdomadaires
- nombre de commandes ;
- chiffre d'affaires ;
- panier moyen ;
- marge par produit ;
- taux de commandes répétées ;
- coût de livraison ;
- temps moyen de préparation ;
- réclamations et commandes annulées.

## Enseigne et identité
- Logo simplifié pour rester lisible en petit format.
- Enseigne avec le nom, 3 à 5 produits phares, les numéros et une mention de livraison.
- Menu imprimé avec prix lisibles, photos authentiques et catégories claires.
- Garder la même palette : brun/noir, or chaud, orange et blanc crème.

## Phase 2 : paiement en ligne
La première version utilise WhatsApp et ne collecte aucun paiement. Avant d'intégrer Wave ou Orange Money, valider un compte marchand, le prestataire, les frais, la gestion des remboursements et la confirmation automatique des paiements. Ne jamais demander au client d'envoyer son code PIN ou son OTP par WhatsApp.
