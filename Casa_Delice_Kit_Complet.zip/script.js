const products = [
 {id:"burger",name:"Burger",category:"Fast-food",label:"LE CLASSIQUE",desc:"Un grand classique pour une pause généreuse.",image:"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=85"},
 {id:"sandwich",name:"Sandwich",category:"Fast-food",label:"SUR LE POUCE",desc:"Une option pratique quand la faim se fait sentir.",image:"https://images.unsplash.com/photo-1553909489-cd47e0ef937f?auto=format&fit=crop&w=800&q=85"},
 {id:"pizza",name:"Pizza",category:"Fast-food",label:"À PARTAGER",desc:"Une envie de pizza ? Demandez les garnitures disponibles.",image:"https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=85"},
 {id:"tacos",name:"Mini-tacos",category:"Fast-food",label:"GOURMAND",desc:"Une petite taille, une grande envie de se régaler.",image:"https://images.unsplash.com/photo-1624300629298-e9de39c13be5?auto=format&fit=crop&w=800&q=85"},
 {id:"chawarma",name:"Chawarma",category:"Fast-food",label:"LA SIGNATURE",desc:"Un sandwich généreux, à personnaliser selon disponibilité.",image:"https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&w=800&q=85"},
 {id:"nems",name:"Nems",category:"Snacks",label:"À GRIGNOTER",desc:"À partager ou à savourer en entrée.",image:"https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=85"},
 {id:"fataya",name:"Fataya viande",category:"Snacks",label:"LE PETIT PLAISIR",desc:"Une spécialité snack pour combler une petite faim.",image:"https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=85"},
 {id:"riz-poulet",name:"Riz au poulet",category:"Plats",label:"LE REPAS",desc:"Un plat de riz à commander selon les disponibilités du jour.",image:"https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=800&q=85"},
 {id:"riz-poisson",name:"Riz au poisson",category:"Plats",label:"SAVEUR LOCALE",desc:"Une option inspirée des saveurs appréciées au Sénégal.",image:"https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=85"}
];
const cart = new Map();
const grid = document.querySelector("#product-grid");
const cartItems = document.querySelector("#cart-items");
const cartCount = document.querySelector("#cart-count");
const fallbackImage = "https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=800&q=80";

function renderProducts(filter="Tous"){
  grid.innerHTML = "";
  products.filter(p => filter==="Tous" || p.category===filter).forEach(p=>{
    const card=document.createElement("article");
    card.className="product-card";
    card.innerHTML=`<div class="product-image"><img src="${p.image}" alt="${p.name}" loading="lazy"><span class="product-category">${p.label}</span></div><div class="product-info"><div class="product-title-row"><h3>${p.name}</h3><span class="price-tag">Prix à confirmer</span></div><p>${p.desc}</p><button class="add-button" data-add="${p.id}">Ajouter au panier <span>＋</span></button></div>`;
    const img=card.querySelector("img");
    img.addEventListener("error",()=>{img.src=fallbackImage;});
    grid.appendChild(card);
  });
}
function renderCart(){
  const total=[...cart.values()].reduce((sum,item)=>sum+item.qty,0);
  cartCount.textContent=total;
  if(!cart.size){cartItems.innerHTML='<div class="empty-cart"><span>＋</span><p>Votre panier est encore vide.</p><small>Ajoutez un produit depuis le menu.</small></div>';return;}
  cartItems.innerHTML="";
  cart.forEach((item,id)=>{
    const row=document.createElement("div");row.className="cart-item";
    row.innerHTML=`<div><b>${item.product.name}</b><small>Prix à confirmer</small></div><div class="quantity-control"><button data-minus="${id}" aria-label="Retirer une unité">−</button><b>${item.qty}</b><button data-plus="${id}" aria-label="Ajouter une unité">+</button></div><button class="remove-item" data-remove="${id}" aria-label="Supprimer ${item.product.name}">×</button>`;
    cartItems.appendChild(row);
  });
}
grid.addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(!b)return;const p=products.find(x=>x.id===b.dataset.add);if(!p)return;const existing=cart.get(p.id);cart.set(p.id,{product:p,qty:existing?existing.qty+1:1});renderCart();b.innerHTML='Ajouté <span>✓</span>';setTimeout(()=>{b.innerHTML='Ajouter au panier <span>＋</span>';},900);});
cartItems.addEventListener("click",e=>{
 const plus=e.target.closest("[data-plus]"),minus=e.target.closest("[data-minus]"),remove=e.target.closest("[data-remove]");
 if(plus){const i=cart.get(plus.dataset.plus);i.qty++;cart.set(plus.dataset.plus,i);}
 if(minus){const i=cart.get(minus.dataset.minus);i.qty--;if(i.qty<=0)cart.delete(minus.dataset.minus);else cart.set(minus.dataset.minus,i);}
 if(remove)cart.delete(remove.dataset.remove);
 renderCart();
});
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));btn.classList.add("active");renderProducts(btn.dataset.filter);}));
document.querySelector("#clear-cart").addEventListener("click",()=>{cart.clear();renderCart();});
document.querySelector("#checkout").addEventListener("click",()=>{
 if(!cart.size){alert("Ajoutez au moins un produit à votre panier avant de commander.");return;}
 const number=document.querySelector("#whatsapp-number").value;
 const mode=document.querySelector("#order-mode").value;
 const note=document.querySelector("#customer-note").value.trim();
 const lines=[...cart.values()].map(i=>`• ${i.product.name} × ${i.qty}`).join("\n");
 const message=`Bonjour Casa Délice ! Je souhaite passer une commande :\n\n${lines}\n\nMode souhaité : ${mode}\nPrécisions : ${note||"Aucune"}\n\nPouvez-vous me confirmer les prix, la disponibilité et les modalités, s'il vous plaît ?`;
 window.open(`https://wa.me/${number}?text=${encodeURIComponent(message)}`,"_blank","noopener,noreferrer");
});
const toggle=document.querySelector(".nav-toggle"),nav=document.querySelector(".main-nav");
toggle.addEventListener("click",()=>{const open=nav.classList.toggle("open");toggle.setAttribute("aria-expanded",String(open));toggle.textContent=open?"×":"☰";});
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>{nav.classList.remove("open");toggle.setAttribute("aria-expanded","false");toggle.textContent="☰";}));
document.querySelector("#year").textContent=new Date().getFullYear();
renderProducts();renderCart();