# Casa Délice — site vitrine + commandes WhatsApp

Site statique en français, conçu pour Casa Délice à Niaga / Lac Rose.

## Fichiers
- `index.html` : page et sections du site
- `styles.css` : design responsive
- `script.js` : catalogue, filtres, panier et commande WhatsApp
- `assets/logo.svg` : logo vectoriel modifiable

## Tester le site
Ouvrir `index.html` dans un navigateur. Pour le publier, téléverser tous les fichiers et le dossier `assets` dans un dépôt GitHub puis activer GitHub Pages.

## Informations déjà intégrées
- Localisation générale : Niaga / Lac Rose
- Téléphones : 78 942 94 49 et 78 333 56 72
- Produits : nems, burger, sandwich, pizza, mini-tacos, chawarma, fataya viande, riz au poulet, riz au poisson
- Commandes par WhatsApp avec panier, choix du numéro, mode de retrait/livraison et note client
- Les tarifs sont volontairement affichés « Prix à confirmer »

## À confirmer avant publication
1. Adresse exacte / point Google Maps
2. Prix de chaque produit et éventuels suppléments
3. Horaires et jours d'ouverture
4. Zones, frais et délais de livraison
5. Confirmation des numéros WhatsApp
6. Photos authentiques des plats et autorisation de les publier
7. Politique de confidentialité si des outils de suivi ou de collecte sont ajoutés

## Paiement
La version actuelle n'encaisse aucun paiement en ligne. Elle prépare la commande puis l'envoie sur WhatsApp. Le paiement en ligne (Wave / Orange Money ou autre prestataire) pourra être ajouté ultérieurement après validation du compte marchand et du parcours de paiement.

## Images
Les images culinaires utilisent des liens distants Unsplash. Remplacez-les par des photos authentiques de Casa Délice dès qu'elles sont disponibles, afin d'éviter tout décalage entre les photos et les plats réellement servis.

## Personnalisation
Les produits et catégories se trouvent dans le tableau `products` de `script.js`. Pour ajouter un produit, copiez un objet, donnez-lui un identifiant unique, un nom, une catégorie, une description et une URL d'image.
